<form method="post">

<input placeholder="Admin Name">

<input placeholder="Telegram Link">

<textarea placeholder="Description"></textarea>

<button>Save</button>

</form>