<?php
include "../config.php";

if(isset($_POST['add'])){

$name=$_POST['name'];
$msg=$_POST['msg'];

mysqli_query($conn,"INSERT INTO reviews(name,message)
VALUES('$name','$msg')");

}
?>

<form method="post">

<input name="name" placeholder="Name">

<textarea name="msg"></textarea>

<button name="add">Add Review</button>

</form>