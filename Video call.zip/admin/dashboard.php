<?php
session_start();

if(!isset($_SESSION['admin'])){
header("Location: login.php");
}
?>

<h1>Admin Dashboard</h1>

<ul>

<li><a href="products.php">Manage Products</a></li>

<li><a href="reviews.php">Manage Reviews</a></li>

<li><a href="settings.php">Payment Settings</a></li>

<li><a href="profile.php">Profile Settings</a></li>

<li><a href="logout.php">Logout</a></li>

</ul>