<?php
include "../config.php";

if(isset($_POST['save'])){

$upi=$_POST['upi'];
$demo=$_POST['demo'];

mysqli_query($conn,"UPDATE settings 
SET upi_id='$upi', demo_link='$demo'");

}
?>

<form method="post">

<input name="upi" placeholder="UPI ID">

<input name="demo" placeholder="Demo Link">

<button name="save">Save</button>

</form>