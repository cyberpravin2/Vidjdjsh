<?php
session_start();

if(isset($_POST['login'])){

$user = $_POST['username'];
$pass = $_POST['password'];

if($user=="admin" && $pass=="admin123"){

$_SESSION['admin']=true;

header("Location: dashboard.php");

}

}
?>

<form method="post">

<h2>Admin Login</h2>

<input type="text" name="username" placeholder="Username">

<input type="password" name="password" placeholder="Password">

<button name="login">Login</button>

</form>