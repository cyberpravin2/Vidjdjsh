<?php
include "../config.php";

if(isset($_POST['add'])){

$title = $_POST['title'];
$price = $_POST['price'];

mysqli_query($conn,"INSERT INTO products(title,price)
VALUES('$title','$price')");

}
?>

<h2>Products</h2>

<form method="post">

<input name="title" placeholder="Product Title">

<input name="price" placeholder="Price">

<button name="add">Add Product</button>

</form>